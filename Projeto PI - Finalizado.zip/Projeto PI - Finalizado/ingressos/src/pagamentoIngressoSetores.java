
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class pagamentoIngressoSetores extends javax.swing.JFrame {

    private int n;

    public pagamentoIngressoSetores() {
        initComponents();
        int n = (int) Math.floor(Math.random() * 10000);
        jLabel11.setText(String.valueOf(n));
        this.n = n;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtNomeCompleto = new javax.swing.JLabel();
        txtnomeCompleto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtcpf = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtdata = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txttel = new javax.swing.JTextField();
        txtEmail = new javax.swing.JLabel();
        txtemail = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        txtEndereço = new javax.swing.JLabel();
        txtendereco = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtnumeroCartao = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtnomeTitular = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtcpfCartao = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtvalidade = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        txtcvv = new javax.swing.JTextField();
        btnConfirmar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setText("Número do pedido:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 30, 150, 16);

        txtNomeCompleto.setText("Nome Completo:");
        getContentPane().add(txtNomeCompleto);
        txtNomeCompleto.setBounds(10, 100, 120, 20);

        txtnomeCompleto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnomeCompletoActionPerformed(evt);
            }
        });
        getContentPane().add(txtnomeCompleto);
        txtnomeCompleto.setBounds(120, 100, 140, 26);

        jLabel3.setText("CPF:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(280, 100, 110, 16);
        getContentPane().add(txtcpf);
        txtcpf.setBounds(320, 100, 140, 26);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(0, 50, 0, 3);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("                                                      Pedido");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 0, 1290, 20);
        getContentPane().add(jSeparator2);
        jSeparator2.setBounds(0, 50, 1290, 10);

        jLabel5.setText("                                                                 Dados Pessoais");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(0, 60, 1280, 16);

        jLabel6.setText("Data de Nascimento:");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(10, 140, 110, 16);

        txtdata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdataActionPerformed(evt);
            }
        });
        getContentPane().add(txtdata);
        txtdata.setBounds(120, 140, 140, 26);

        jLabel7.setText("Telefone:");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(280, 140, 80, 16);
        getContentPane().add(txttel);
        txttel.setBounds(330, 140, 130, 26);

        txtEmail.setText("E-mail:");
        getContentPane().add(txtEmail);
        txtEmail.setBounds(10, 180, 110, 16);

        txtemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtemailActionPerformed(evt);
            }
        });
        getContentPane().add(txtemail);
        txtemail.setBounds(60, 180, 140, 26);
        getContentPane().add(jSeparator3);
        jSeparator3.setBounds(0, 253, 480, 10);

        jLabel9.setText("                                                                      Pagamento");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(0, 260, 480, 16);

        txtEndereço.setText("Endereço:");
        getContentPane().add(txtEndereço);
        txtEndereço.setBounds(240, 180, 60, 30);
        getContentPane().add(txtendereco);
        txtendereco.setBounds(300, 180, 160, 26);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jLabel11);
        jLabel11.setBounds(150, 26, 70, 20);

        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton1);
        jRadioButton1.setBounds(0, 300, 19, 20);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logotipo (3).png"))); // NOI18N
        getContentPane().add(jLabel12);
        jLabel12.setBounds(30, 290, 160, 40);

        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton2);
        jRadioButton2.setBounds(150, 300, 19, 20);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-visa-96.png"))); // NOI18N
        getContentPane().add(jLabel13);
        jLabel13.setBounds(170, 290, 100, 40);

        jLabel14.setText("Número do Cartão: ");
        getContentPane().add(jLabel14);
        jLabel14.setBounds(10, 360, 110, 16);

        txtnumeroCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnumeroCartaoActionPerformed(evt);
            }
        });
        getContentPane().add(txtnumeroCartao);
        txtnumeroCartao.setBounds(10, 380, 230, 30);

        jLabel15.setText("Nome do titular:");
        getContentPane().add(jLabel15);
        jLabel15.setBounds(10, 420, 140, 16);

        txtnomeTitular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnomeTitularActionPerformed(evt);
            }
        });
        getContentPane().add(txtnomeTitular);
        txtnomeTitular.setBounds(10, 440, 230, 30);

        jLabel16.setText("CPF do proprietário do cartão:");
        getContentPane().add(jLabel16);
        jLabel16.setBounds(10, 480, 230, 16);

        txtcpfCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcpfCartaoActionPerformed(evt);
            }
        });
        getContentPane().add(txtcpfCartao);
        txtcpfCartao.setBounds(10, 500, 230, 30);

        jLabel17.setText("Validade:");
        getContentPane().add(jLabel17);
        jLabel17.setBounds(310, 360, 100, 16);
        getContentPane().add(txtvalidade);
        txtvalidade.setBounds(310, 380, 100, 30);

        jLabel18.setText("CVV:");
        getContentPane().add(jLabel18);
        jLabel18.setBounds(310, 420, 100, 16);
        getContentPane().add(txtcvv);
        txtcvv.setBounds(310, 440, 100, 30);

        btnConfirmar.setBackground(new java.awt.Color(0, 0, 0));
        btnConfirmar.setForeground(new java.awt.Color(255, 255, 255));
        btnConfirmar.setText("Confirmar");
        btnConfirmar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });
        getContentPane().add(btnConfirmar);
        btnConfirmar.setBounds(60, 550, 120, 30);

        btnLimpar.setBackground(new java.awt.Color(0, 0, 0));
        btnLimpar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpar.setText("Limpar");
        btnLimpar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpar);
        btnLimpar.setBounds(260, 550, 120, 30);

        jPanel1.setBackground(new java.awt.Color(204, 0, 0));
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 480, 50);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 50, 490, 570);

        setSize(new java.awt.Dimension(499, 626));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtnomeCompletoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnomeCompletoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnomeCompletoActionPerformed

    private void txtdataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdataActionPerformed

    private void txtemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtemailActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        String cartaoselecionado;
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void txtnumeroCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnumeroCartaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnumeroCartaoActionPerformed

    private void txtnomeTitularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnomeTitularActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnomeTitularActionPerformed

    private void txtcpfCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcpfCartaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcpfCartaoActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        String nome, email, endereco, data, telefone, cpf;

        nome = txtnomeCompleto.getText();
        email = txtemail.getText();
        endereco = txtendereco.getText();
        data = txtdata.getText();
        telefone = txttel.getText();
        cpf = txtcpf.getText();

        try {
            new ingressoDao().salvarPagamento(nome, email, endereco, data, telefone, cpf);
            JOptionPane.showMessageDialog(null, "Pagamento Confirmado");
        } catch (ClassNotFoundException ex) {

            JOptionPane.showMessageDialog(null, "Erro " + ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro " + ex.getMessage());
        }
        new ReciboPagamento(n).setVisible(true);
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        txtnomeCompleto.setText("");
        txtcpf.setText("");
        txtdata.setText("");
        txtemail.setText("");
        txtendereco.setText("");
        txtnumeroCartao.setText("");
        txtvalidade.setText("");
        txtnomeTitular.setText("");
        txtcvv.setText("");
        txtcpfCartao.setText("");
    }//GEN-LAST:event_btnLimparActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pagamentoIngressoSetores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pagamentoIngressoSetores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pagamentoIngressoSetores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pagamentoIngressoSetores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel txtEmail;
    private javax.swing.JLabel txtEndereço;
    private javax.swing.JLabel txtNomeCompleto;
    private javax.swing.JTextField txtcpf;
    private javax.swing.JTextField txtcpfCartao;
    private javax.swing.JTextField txtcvv;
    private javax.swing.JTextField txtdata;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtendereco;
    private javax.swing.JTextField txtnomeCompleto;
    private javax.swing.JTextField txtnomeTitular;
    private javax.swing.JTextField txtnumeroCartao;
    private javax.swing.JTextField txttel;
    private javax.swing.JTextField txtvalidade;
    // End of variables declaration//GEN-END:variables

}
