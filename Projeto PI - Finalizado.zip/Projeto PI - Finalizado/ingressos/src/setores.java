
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;

public class setores extends javax.swing.JFrame {

    private ButtonGroup tipoIngressoGroup;
    private String tipoIngresso;
    private String setorSelecionado;
    private int quantidade;

    public setores() {
        initComponents();
        int Norte = 1500;
        int Sul = 1500;
        int Leste = 1500;
        int Oeste = 1500;

        tipoIngressoGroup = new ButtonGroup();
        tipoIngressoGroup.add(rdbArq);
        tipoIngressoGroup.add(rdbCad);

    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cbxSetorcadeiras = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        spnQtdarq = new javax.swing.JSpinner();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        cbxSetorarq = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        spnQtdcadeiras = new javax.swing.JSpinner();
        btnAvancar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        rdbArq = new javax.swing.JRadioButton();
        rdbCad = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblvalorCad = new javax.swing.JLabel();
        lblvalorArq = new javax.swing.JLabel();
        lblvalorArq1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("                   SETORES");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 10, 260, 16);

        cbxSetorcadeiras.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Norte", "Sul", "Leste", "Oeste" }));
        getContentPane().add(cbxSetorcadeiras);
        cbxSetorcadeiras.setBounds(90, 280, 170, 26);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(0, 40, 270, 3);

        jLabel3.setText("SETOR:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 106, 70, 20);

        jLabel4.setText("QUANTIDADE:");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(10, 156, 80, 30);
        getContentPane().add(spnQtdarq);
        spnQtdarq.setBounds(90, 160, 160, 26);
        getContentPane().add(jSeparator2);
        jSeparator2.setBounds(0, 240, 260, 3);

        jLabel6.setText("SETOR:");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(10, 280, 80, 30);

        cbxSetorarq.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Norte", "Sul", "Leste", "Oeste" }));
        cbxSetorarq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxSetorarqActionPerformed(evt);
            }
        });
        getContentPane().add(cbxSetorarq);
        cbxSetorarq.setBounds(90, 100, 170, 26);

        jLabel7.setText("QUANTIDADE:");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(10, 340, 80, 30);
        getContentPane().add(spnQtdcadeiras);
        spnQtdcadeiras.setBounds(90, 340, 160, 26);

        btnAvancar.setBackground(new java.awt.Color(0, 0, 0));
        btnAvancar.setForeground(new java.awt.Color(255, 255, 255));
        btnAvancar.setText("Avançar");
        btnAvancar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAvancar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAvancarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAvancar);
        btnAvancar.setBounds(10, 440, 110, 20);

        btnLimpar.setBackground(new java.awt.Color(0, 0, 0));
        btnLimpar.setForeground(new java.awt.Color(255, 255, 255));
        btnLimpar.setText("Limpar");
        btnLimpar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(btnLimpar);
        btnLimpar.setBounds(140, 440, 110, 20);

        rdbArq.setText("Arquibancada");
        rdbArq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbArqActionPerformed(evt);
            }
        });
        getContentPane().add(rdbArq);
        rdbArq.setBounds(10, 50, 240, 21);

        rdbCad.setText("Cadeiras");
        rdbCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbCadActionPerformed(evt);
            }
        });
        getContentPane().add(rdbCad);
        rdbCad.setBounds(10, 250, 240, 21);

        jLabel2.setText("VALOR:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 380, 90, 30);

        jLabel5.setText("VALOR:");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 200, 70, 30);
        getContentPane().add(lblvalorCad);
        lblvalorCad.setBounds(70, 376, 110, 40);

        lblvalorArq.setText("R$ 130,00");
        getContentPane().add(lblvalorArq);
        lblvalorArq.setBounds(60, 370, 90, 50);

        lblvalorArq1.setText("R$ 130,00");
        getContentPane().add(lblvalorArq1);
        lblvalorArq1.setBounds(60, 190, 90, 50);

        jPanel1.setBackground(new java.awt.Color(204, 0, 0));
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 260, 40);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 40, 260, 470);

        setSize(new java.awt.Dimension(276, 521));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAvancarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAvancarActionPerformed

        String setorSelecionado;
        int quantidade;

        if (rdbArq.isSelected()) {
            setorSelecionado = cbxSetorarq.getSelectedItem().toString();
            quantidade = (int) spnQtdarq.getValue();
        } else if (rdbCad.isSelected()) {
            setorSelecionado = cbxSetorcadeiras.getSelectedItem().toString();
            quantidade = (int) spnQtdcadeiras.getValue();
        } else {
            // Se nenhum setor estiver selecionado, vai exibir  uma mensagem de erro e retornar
            JOptionPane.showMessageDialog(this, "Selecione um setor.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        new pedidoIngresso().setVisible(true);
        this.dispose();  // Fechar a tela atual
    }//GEN-LAST:event_btnAvancarActionPerformed

    private void cbxSetorarqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxSetorarqActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxSetorarqActionPerformed

    private void rdbArqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbArqActionPerformed
        if (rdbArq.isSelected()) {
            cbxSetorcadeiras.setEnabled(false);
            spnQtdcadeiras.setEnabled(false);
            cbxSetorarq.setEnabled(true);
            spnQtdarq.setEnabled(true);
        }
    }//GEN-LAST:event_rdbArqActionPerformed

    private void rdbCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbCadActionPerformed
        if (rdbCad.isSelected()) {
            cbxSetorarq.setEnabled(false);
            spnQtdarq.setEnabled(false);
            cbxSetorcadeiras.setEnabled(true); // reabilita as outras opções
            spnQtdcadeiras.setEnabled(true);
        }
    }//GEN-LAST:event_rdbCadActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(setores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(setores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(setores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(setores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new setores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAvancar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JComboBox<String> cbxSetorarq;
    private javax.swing.JComboBox<String> cbxSetorcadeiras;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblvalorArq;
    private javax.swing.JLabel lblvalorArq1;
    private javax.swing.JLabel lblvalorCad;
    private javax.swing.JRadioButton rdbArq;
    private javax.swing.JRadioButton rdbCad;
    private javax.swing.JSpinner spnQtdarq;
    private javax.swing.JSpinner spnQtdcadeiras;
    // End of variables declaration//GEN-END:variables
}
