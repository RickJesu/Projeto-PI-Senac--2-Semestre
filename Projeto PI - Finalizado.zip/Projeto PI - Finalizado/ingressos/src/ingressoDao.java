
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ingressoDao {

    Connection conectar;

    private void conectar() throws ClassNotFoundException, SQLException {
        //Conectar ao banco de dados empresa
        Class.forName("com.mysql.cj.jdbc.Driver");
        conectar = DriverManager.getConnection("jdbc:mysql://localhost:3306/saopaulo", "root", "");

    }

    public void salvarPagamento(String nome, String email, String endereco, String data, String telefone, String cpf)
            throws ClassNotFoundException, SQLException {
        conectar();
        //3 - Enviar os dados para a tabela do BD
        PreparedStatement st = conectar.prepareStatement("INSERT INTO pagamento VALUES (?,?,?,?,?,?)");
        st.setString(1, nome);
        st.setString(2, email);
        st.setString(3, endereco);
        st.setString(4, data);
        st.setString(5, telefone);
        st.setString(6, cpf);
        st.executeUpdate();

    }

    public void salvarJogos(String confronto, String data, String hora)
            throws ClassNotFoundException, SQLException {
        conectar();
        //3 - Enviar os dados para a tabela do BD
        PreparedStatement st = conectar.prepareStatement("INSERT INTO jogos VALUES (?,?,?)");
        st.setString(1, confronto);
        st.setString(2, data);
        st.setString(3, hora);
        st.executeUpdate();

    }
}
